Contact Form
=========

A simple and easy to customize contact form.

[Article on CodyHouse](http://codyhouse.co/gem/css-contact-form/)

[Demo](http://codyhouse.co/demo/contact-form/index.html)

Icons from [Nucleo](http://nucleoapp.com/)
 
[Terms](http://codyhouse.co/terms/)
